//bill split / tip / rounder

function splitBill() {

    // gather user inputs
    var total = Number(prompt("Enter the total bill (ex: 150.45):"));
    var people = Number(prompt("Enter number of people:"));
    var tipPercent = Number(prompt("Enter the tip percent (ex: 15):")) / 100;

    // calculate totals
    var subtotalPer = total / people;
    var tipPer = subtotalPer * tipPercent;
    var totalPer = subtotalPer + tipPer;

    // prompt for rounding choice
    var rounding = prompt(
        "Choose rounding (Anything not 1 or 2 will default to cent rounding):\n" +
        "1 - Round up to next cent\n" +
        "2 - Round up to next dollar"
    );

    // IF for rounding option
    if (rounding === "1") {
        totalPer = Math.ceil(totalPer * 100) / 100; // * 100 for cents round, / 100 to return to dollar amount
    } else if (rounding === "2") {
        totalPer = Math.ceil(totalPer); // leave for full dollar rounding
    } else {
        totalPer = Math.ceil(totalPer * 100) / 100;
    }

    // totals for all people combined
    var combinedTotal = subtotalPer * people;
    var combinedTotalWithTip = totalPer * people;

    // output variables
    var outSubtotal = "Subtotal per person: $" + subtotalPer.toFixed(2) + "<br>";
    var outTip = "Tip per person: $" + tipPer.toFixed(2) + "<br>";
    var outTotal = "Total per person: $" + totalPer.toFixed(2) + "<br>";
    var outTotalAll = "Total for all people (without tip): $" + combinedTotal.toFixed(2) + "<br>";
    var outTotalWithTipAll = "Total for all people (with tip): $" + combinedTotalWithTip.toFixed(2) + "<br>";

    //output subtotal, tip, total per person and total for all
    document.write(outSubtotal);
    document.write(outTip);
    document.write(outTotal);
    document.write(outTotalAll);
    document.write(outTotalWithTipAll);
    document.write("<br>------------------------------<br><br>");
}

// loop for if they want to add another bill
var again = "yes";

while (again === "yes") {
    splitBill();
    again = prompt("Do another bill? (yes/no)");
}